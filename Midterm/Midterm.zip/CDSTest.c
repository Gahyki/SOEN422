#include "CDS.h"


void main() {

    printf("Test CDS");

    Object_Init(); // setup()

    while(true) { // loop()


    }
}
