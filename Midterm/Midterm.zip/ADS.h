#ifndef __ADS_h
#define __ADS_h

#include <stdbool.h>
// #include <avr/io.h>
// #include <util/delay.h>


void Object_Init(); // Constructor method
void Object_Method(); // Method

#endif // __ADS_h