#include "CDS.h"

typedef struct Object{

} Object;

Object o;

void Object_Init(void) {
    // Constructor method
}

void Object_Method(void) {
    // Method
}
