#ifndef __CDS_h
#define __CDS_h

#include <stdbool.h>
// #include <avr/io.h>
// #include <util/delay.h>

typedef struct Object;
void Object_Init();
void Object_Method();

#endif // __CDS_h