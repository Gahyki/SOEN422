#include "Task3.h"

typedef struct{

} Object;

static Object o;

void Object_Init(){
    // Constructor method
}

void Object_Method(){

}