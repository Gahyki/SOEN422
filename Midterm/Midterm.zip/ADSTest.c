#include "ADS.h"


void main() {

    printf("Test blinking LED as an ADS");

    Object_Init(); // setup()

    while (true) { // loop()

    }
}
