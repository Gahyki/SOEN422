#include "ADT.h"

int main(){
    
    Object o = Object_New(); // setup Bargraph    

    while(true){

    }

    return 0;
}