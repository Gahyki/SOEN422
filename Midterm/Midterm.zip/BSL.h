#ifndef __bsl_h
#define __bsl_h

#define var1 value
#define var2 value

#endif // __bsl_h