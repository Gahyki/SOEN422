#include "Task2.h"


void main() {

    printf("Test blinking LED as a CDS");

    Led_Init(); // setup()

    while (true) { // loop()
        Led_TurnOn(); // Turn on the LED
        Led_TurnOff(); // Turn off the LED
    }
}
