// #include <stdbool.h>
#include <avr/io.h>
#include <util/delay.h>

typedef struct Led{

} Led;

Led led;

void Led_Init(void) {
    DDRB |= (1 << 5); // Modify the pinMode to Output mode
}

void Led_TurnOff(void) {
    PORTB &= ~(1 << 5); // Clear the bit to turn it off
    _delay_ms(1000);        // Wait a second.
}
void Led_TurnOn(void) {
    PORTB |= (1 << 5);  // Modify the bit to turn it on
    _delay_ms(1000);        // Wait a second.
}